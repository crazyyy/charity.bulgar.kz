
//variable declaration. data from user
var userName = prompt("Введите Ваше имя", "имя");

//display result. greeting
alert("Добрый день " + userName);