
//variable declaration
var developer;
var name;

//name initialization
name = "Sergey";

//copy data
developer = name;

//display result
alert(developer);