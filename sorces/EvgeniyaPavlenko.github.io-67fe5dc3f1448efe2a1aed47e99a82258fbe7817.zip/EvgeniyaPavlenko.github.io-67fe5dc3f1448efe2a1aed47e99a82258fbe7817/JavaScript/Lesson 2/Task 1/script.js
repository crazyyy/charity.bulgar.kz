
//variable declaration. Year from user
var year = prompt("ведите какой сейчас год");

//The correct answer only - 2015. Otherwise - we say the right version.
if(year == "2015"){
	alert("Вы правы!");
}else{
	alert("С луны свалися? 2015!");
}