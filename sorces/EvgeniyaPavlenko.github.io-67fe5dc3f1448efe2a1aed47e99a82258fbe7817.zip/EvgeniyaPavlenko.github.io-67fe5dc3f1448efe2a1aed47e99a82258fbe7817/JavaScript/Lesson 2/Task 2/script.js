
//variable declaration. number from user
var number = prompt("Введите любое целое число?");

//check the input number. <0-"-1". >0-"1". 0-"0".
if (number < 0){
	alert("-1");
}else if (number == "0"){
	alert("0");
}else{
	alert("1");
}


