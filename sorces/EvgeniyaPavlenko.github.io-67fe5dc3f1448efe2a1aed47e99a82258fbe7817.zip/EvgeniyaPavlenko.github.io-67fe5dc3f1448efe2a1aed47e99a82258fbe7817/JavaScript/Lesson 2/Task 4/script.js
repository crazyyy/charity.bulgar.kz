//variable declaration
var a = 1, b = 2;

//result initialization
var result = (a + b >= 3) ?  "Yep!" : "Noup!";

//show data
console.log(result);