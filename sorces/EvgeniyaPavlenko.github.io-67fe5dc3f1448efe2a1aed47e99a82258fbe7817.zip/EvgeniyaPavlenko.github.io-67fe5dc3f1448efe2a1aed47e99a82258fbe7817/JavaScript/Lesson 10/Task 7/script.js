function suffle(arr){
	return arr.reverse();
}

var arr = [1, 2, 3, "a", "b"];
console.log(suffle(arr));