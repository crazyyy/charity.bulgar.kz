function rightOrder(str){
	return str.split("").sort().join("");
}

console.log(rightOrder("webmaster"));